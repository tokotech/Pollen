﻿using System.Runtime.Serialization;

namespace Pollen.Model
{
    /// <summary>
    /// settings":{"push_daily":"0","push_warnings":"1","bi":"0","by":"0","el":"0","elm":"0","gr":"0","ha":"0","al":"0","cl":"0"},
    /// </summary>
    [DataContract]
    public class SettingsData
    {
        [DataMember(Name = "push_daily")]
        public string PushDaily { get; set; }
        [DataMember(Name = "push_warnings")]
        public string PushWarnings { get; set; }
        [DataMember(Name = "bi")]
        public string Bi { get; set; }
        [DataMember(Name = "by")]
        public string By { get; set; }
        [DataMember(Name = "el")]
        public string El { get; set; }
        [DataMember(Name = "elm")]
        public string Elm { get; set; }
        [DataMember(Name = "gr")]
        public string Gr { get; set; }
        [DataMember(Name = "ha")]
        public string Ha { get; set; }
        [DataMember(Name = "al")]
        public string Al { get; set; }
        [DataMember(Name = "cl")]
        public string Cl { get; set; }
    }
}
