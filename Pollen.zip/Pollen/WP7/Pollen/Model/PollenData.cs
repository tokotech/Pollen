﻿using System.Runtime.Serialization;

namespace Pollen.Model
{
    /// <summary>
    /// {"name":"elm","title":"Elm","kbh":"0","vib":"0","color":1},
    /// </summary>
    [DataContract]
    public class PollenData
    {
        [DataMember(Name = "name")]
        public string Name { get; set; }
        [DataMember(Name = "title")]
        public string Title { get; set; }
        [DataMember(Name = "kbh")]
        public string Kbh { get; set; }
        [DataMember(Name = "vib")]
        public string Vib { get; set; }
        [DataMember(Name = "color")]
        public string Color { get; set; }
    }
}
