﻿using System;
using System.Runtime.Serialization;

namespace Pollen.Model
{
    /// <summary>
    ///  {"success":"1",
    ///  "date":"1380146400",
    ///  "pollen":[{"name":"gr","title":"Gr\u00e6s","kbh":"1","vib":"0","color":2},
    ///            {"name":"bi","title":"Birk","kbh":"0","vib":"0","color":1},
    ///            {"name":"by","title":"Bynke","kbh":"0","vib":"0","color":1},
    ///            {"name":"elm","title":"Elm","kbh":"0","vib":"0","color":1},
    ///            {"name":"ha","title":"Hassel","kbh":"0","vib":"0","color":1},
    ///            {"name":"el","title":"El","kbh":"0","vib":"0","color":1}],
    ///  "forecast":[{"name":"bi","title":"Birk","kbh":"0","vib":"0","color":1},
    ///              {"name":"by","title":"Bynke","kbh":"0","vib":"0","color":1},
    ///              {"name":"gr","title":"Gr\u00e6s","kbh":"0","vib":"0","color":1}],
    ///  "spore":[{"name":"cl","title":"Cladosporium","kbh":"Lav","vib":"0","color":1},
    ///           {"name":"al","title":"Alternaria","kbh":"Lav","vib":"0","color":1}],
    ///  "settings":{"push_daily":"0","push_warnings":"1","bi":"0","by":"0","el":"0","elm":"0","gr":"0","ha":"0","al":"0","cl":"0"},
    ///  "link":"http:\/\/hoefeber.astma-allergi.dk\/hoefeber\/pollen\/dagenspollental\/erdagenspollentalhoejtellerlavt"}
    /// </summary>
    [DataContract]
    public class FeedData
    {
        [DataMember(Name = "success")]
        public Int32 Success { get; set; }

        [DataMember(Name = "date")]
        public string Date { get; set; }

        [DataMember(Name = "settings")]
        public SettingsData Settings { get; set; }

        [DataMember(Name = "link")]
        public string Link { get; set; }

        [DataMember(Name = "pollen")]
        public PollenData[] Pollen { get; set; }

        [DataMember(Name = "forecast")]
        public PollenData[] Forecast { get; set; }

        [DataMember(Name = "spore")]
        public PollenData[] Spore { get; set; }
    }
}
