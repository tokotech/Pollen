﻿using System.Windows;
using GalaSoft.MvvmLight.Messaging;

namespace Pollen.View
{
    public partial class MainView 
    {
        public MainView()
        {
            InitializeComponent();
            Messenger.Default.Register<DialogMessage>(this, action => ReceiveGotoPageMessage(action));
        }

        private static object ReceiveGotoPageMessage(DialogMessage action)
        {
            MessageBox.Show(action.Content,"Der opstod en fejl",MessageBoxButton.OK);
            return null;
        }
    }
}