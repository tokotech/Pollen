﻿using System;
using System.Collections.ObjectModel;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using Microsoft.Phone.Tasks;
using Pollen.Model;
using Pollen.Services;

namespace Pollen.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        private readonly IDataService _dataService;
        private const string Url = "http://pollental.astma-allergi.woerk.dk/feed.json?lang=da&version=1.1";

        public MainViewModel(IDataService dataService)
        {
            _dataService = dataService;
            PollenList = new ObservableCollection<PollenData>();
            ForeCastList = new ObservableCollection<PollenData>();
            RateThisApp = new RelayCommand(Ratelink_Click);
            ShowMoreApps = new RelayCommand(ShowMoreApps_Click);
            LoadData();
        }

        public RelayCommand RateThisApp { get; set; }
        public RelayCommand ShowMoreApps { get; set; }
        public ObservableCollection<PollenData> PollenList { get; set; }
        public ObservableCollection<PollenData> ForeCastList { get; set; }

        private string _date;
        public string Date
        {
            get { return _date; }
            set
            {
                _date = value;
                RaisePropertyChanged("Date");
            }
        }

        public void LoadData()
        {
            try
            {
                _dataService.GetPollenFeed(Url, (feeds, error) =>
                {
                    if (error == null)
                    {
                        foreach (var pollen in feeds.Pollen)
                            PollenList.Add(pollen);

                        foreach (var pollen in feeds.Spore)
                            PollenList.Add(pollen);

                        foreach (var forecast in feeds.Forecast)
                            ForeCastList.Add(forecast);

                        Date = new DateTime(1970,1,1).AddSeconds(Double.Parse(feeds.Date)).ToString("dd/MM - yyyy");
                    }
                    else
                    {
                        Messenger.Default.Send(new DialogMessage(this, null, "Kunne ikke få forbindelse til DMI", null));
                    }
                });
            }
            catch (Exception)
            {
                Messenger.Default.Send(new DialogMessage(this, null, "Kunne ikke få forbindelse til DMI", null));
            }
        }

        private void Ratelink_Click()
        {
            var marketplaceReviewTask = new MarketplaceReviewTask();
            marketplaceReviewTask.Show();
        }

        private void ShowMoreApps_Click()
        {
            var marketplaceSearchTask = new MarketplaceSearchTask
            {
                ContentType = MarketplaceContentType.Applications,
                SearchTerms = "Tokotech"
            };
            marketplaceSearchTask.Show();
        }
    }
}

/*
 * 
 * 
 * Hvem kan bruge Dagens Pollental?

Dagens Pollental er en hjælp til dig, der har mistanke om allergi eller en kendt pollenallergi. Det vil sige en allergi, der er diagnosticeret af lægen ved fx en priktest. Dagens Pollental er en guide til dig om, hvor vi er i sæsonen.

Det vil sige: Er vi i begyndelsen, ved toppen eller er vi på vej mod slutningen? Det finder du ud af ved at sammenligne Dagens Pollental, der er et øjebliksbillede, med Pollenkalenderen, der viser et normalt sæson forløb. Brug den viden sammen med Dagens Pollenvarsling eller Pollenprognosen til at planlægge dit medicinindtag og daglige udendørs aktiviteter som fx fodboldkampe og vandreture i skoven.

Hvorfor så sent på dagen?

Det er desværre ikke muligt at levere Dagens Pollental tidligere på dagen. Årsagen er den lavteknologiske indsamlingsmetode og det manuelle arbejde, det kræver at frembringe Dagens Pollental. Brug Dagens Pollenvarse eller Pollenprognosen til at planlægge din dag.
Niveauer for Dagens Pollental

For birk, græs og bynke bruger vi niveauer for Dagens Pollenvarsling til at afgøre om Dagens Pollental er lavt, moderat eller højt. For hassel, el og elm udarbejder vi ikke pollenvarsling, men vi er sammen med DMI blevet enige om niveauer til at inddele Dagens Pollental efter.

Hassel

For hassel gælder, at Dagens Pollental er: 

Lavt, når det er under 5 pollen
Moderat, når det er mellem 5 og 15 pollen
Højt, når det er over 15 pollen.
Dagens Pollental for hassel bliver sjældent særlig højt.
Rekorden på 171 hasselpollen for København blev målt 17. marts 2009. Hvilket er exceptionelt højt. 
Rekorden for Viborg er et Dagens Pollental på 23 hasselpollen.

El og elm

For el og elm gælder, at Dagens Pollental er: 

Lavt, når det er under 10 pollen
Moderat, når det er mellem 10 og 50 pollen
Højt, når det er over 50 pollen.
Dagens Pollental for el kan godt blive højt.
Rekorden er et Dagens Pollental på 466 pollen fra 2009. 
Dagens Pollental for elm bliver dog sjældent andet end lavt til moderat. Årsagen til det er elmedøden i 1990'erne, som har givet meget færre elmepollen i luften de senere år.

Birk

For birk gælder, at Dagens Pollental er: 

Lavt, når det er under 30 pollen
Moderat, når det er mellem 30 og 100 pollen
Højt, når det er over 100 pollen.
Dagens Pollental for birk kan blive ekstremt højt.
Rekorden er på 4381 birkepollen i København i 2006. For Viborg er rekorden for samme år på 2.497 pollen.

Det sker næsten hvert år, at vi har Dagens Pollental over 1.000 for birk i København. Derfor undrer nogle sig over, at niveauet højt er sat allerede ved 100 pollen, men alle med allergi over for birkepollen får symptomer, når pollentallet er over 100.

Græs og bynke

For græs og bynke gælder, at Dagens Pollental er: 

Lavt, når det er under 10 pollen
Moderat, når det er mellem 10 og 50 pollen
Højt, når det er over 50 pollen.
Pollensæsonen for græs er lang, og der er mange dage, hvor Dagens Pollental for græs er højt. Rekorden er fra Viborg i 2007 med et pollental på 342 græspollen

Dagens Pollental for bynke er kun få gange om året over 50. Rekorden er et Dagens Pollental på 90 bynkepollen fra København i 2004.

Lav, middel og høj (niveau) for svampesporer:

For Alternaria:

Lav: 0-19
Middel: 20-99
Høj: > 100

For Cladosporium:

Lav: 0-1999
Middel: 2000-5999
Høj: > 6000

 */