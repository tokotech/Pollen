﻿using System;
using Pollen.Model;

namespace Pollen.Services
{
    public class DesignDataService : IDataService
    {
        public void GetPollenFeed(string url, Action<FeedData, Exception> callback)
        {
            var feedData = new FeedData
                {
                    Success = 1,
                    Date = "",
                    Settings = null,
                    Link = "http://www.testdata.com",
                    Pollen = new[]
                        {
                            new PollenData{Name ="bi",Title ="Birk",Kbh = "340",Vib ="330",Color = "1"}, 
                            new PollenData{Name ="elm",Title ="Elm",Kbh = "60",Vib ="660",Color = "1"},
                            new PollenData{Name ="gr",Title ="Græs",Kbh = "10",Vib ="50",Color = "1"}
                        },
                    Forecast = new[]
                        {
                            new PollenData{Name ="bi",Title ="Birk",Kbh = "2340",Vib ="2330",Color = "1"}, 
                            new PollenData{Name ="elm",Title ="Elm",Kbh = "860",Vib ="860",Color = "1"},
                            new PollenData{Name ="gr",Title ="Græs",Kbh = "610",Vib ="4350",Color = "1"}
                        },
                    Spore = new[]
                        {
                            new PollenData{Name ="cl",Title ="Cladosporium",Kbh = "340",Vib ="330",Color = "1"}, 
                            new PollenData{Name ="al",Title ="Alternaria",Kbh = "60",Vib ="660",Color = "1"}
                        },
                };
            callback(feedData, null);
        }
    }
}
