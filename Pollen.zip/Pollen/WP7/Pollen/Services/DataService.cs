﻿using System;
using Newtonsoft.Json;
using Pollen.Model;

namespace Pollen.Services
{
    public class DataService : IDataService
    {
        public void GetPollenFeed(string url, Action<FeedData, Exception> callback)
        {
            WebService.GetWebData(url, (feeds, error) =>
            {
                if (error == null)
                {
                    var feedData = JsonConvert.DeserializeObject<FeedData>(feeds);
                    callback(feedData, null);
                }
                else
                {
                    callback(null, error);
                }
            });
        }
    }
}
