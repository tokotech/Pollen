﻿using System;
using Pollen.Model;

namespace Pollen.Services
{
    public interface IDataService
    {
        void GetPollenFeed(string url, Action<FeedData, Exception> callback);
    }
}
