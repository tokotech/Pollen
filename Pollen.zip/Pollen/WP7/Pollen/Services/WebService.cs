﻿using System;

namespace Pollen.Services
{
    public class WebService
    {

        #region Privatedef

        private static string User = "g43790";
        private static string PW = "okt2013!";

        #endregion

        public static void GetWebData(string url, Action<string, Exception> callback)
        {
            var client = new WSServiceReference.WebProxySoapClient();

            client.GetWebsiteCompleted += (s, ev) =>
            {
                if (ev.Error == null)
                {
                   callback(ev.Result, null);
                }
                else
                {
                    callback(null, ev.Error);
                }
            };

            client.GetWebsiteAsync(url, User, PW);
        }


        //public static void GetWebData(string url, Action<string, Exception> callback)
        //{

        //    var client = new WebClient { Encoding = Encoding.GetEncoding("iso-8859-1") };
        //    client.DownloadStringCompleted += (s, ev) =>
        //    {
        //        if (ev.Error == null)
        //        {
        //            callback(ev.Result, null);
        //        }
        //        else
        //        {
        //            callback(null, ev.Error);
        //        }
        //    };

        //    client.DownloadStringAsync(new Uri(url));
        //}

        //public Task<string> GetWebDataAsync(string url)
        //{
        //    var tcs = new TaskCompletionSource<string>();
        //    var client = new ServiceReference1.WebProxySoapClient();

        //    DownloadStringCompletedEventHandler h = null;
        //    h = (sender, args) =>
        //    {
        //        if (args.Cancelled)
        //        {
        //            tcs.SetCanceled();
        //        }
        //        else if (args.Error != null)
        //        {
        //            tcs.SetException(args.Error);
        //        }
        //        else
        //        {
        //            tcs.SetResult(args.Result);
        //        }

        //        //  client.GetWebsiteCompleted -= h;
        //    };

        //    var darga = new DownloadStringCompletedEventArgs();

        //    client.GetWebsiteCompleted += (s, ev) =>
        //    {

        //        var f = h;
        //        f.Invoke(client, darga);
        //    };

        //    client.GetWebsiteAsync(url, User, PW);

        //    return tcs.Task;
        //}



        //public Task<string> GetWebResultAsync(string url)
        //{
        //    var tcs = new TaskCompletionSource<string>();
        //    var client = new WebClient();

        //    DownloadStringCompletedEventHandler h = null;
        //    h = (sender, args) =>
        //            {
        //                if (args.Cancelled)
        //                {
        //                    tcs.SetCanceled();
        //                }
        //                else if (args.Error != null)
        //                {
        //                    tcs.SetException(args.Error);
        //                }
        //                else
        //                {
        //                    tcs.SetResult(args.Result);
        //                }

        //                client.DownloadStringCompleted -= h;
        //            };

        //    client.DownloadStringCompleted += h;
        //    client.DownloadStringAsync(new Uri(url));

        //    return tcs.Task;
        //}


        //private static void GetWebDataAsync(string url)
        //{
        //    var request = (HttpWebRequest)WebRequest.Create(url);
        //    request.Method = HttpMethod.Get;
        //    request.Accept = "application/json";

        //    try
        //    {
        //        // var response = request.GetResponseAsync().Result as HttpWebResponse;

        //        request.BeginGetResponse(asyncResponse =>
        //        {
        //            try
        //            {
        //               var responseRequest = (HttpWebRequest)asyncResponse.AsyncState;
        //                var someResponse = (HttpWebResponse)responseRequest.EndGetResponse(asyncResponse);


        //                System.IO.Stream responseStream = someResponse.GetResponseStream();
        //                string data;
        //                using (var reader = new System.IO.StreamReader(responseStream))
        //                {
        //                    data = reader.ReadToEnd();
        //                }
        //                responseStream.Close();
        //                Debug.WriteLine(responseRequest.ContentType);
        //            }
        //            catch (WebException webExc)
        //            {
        //                var failedResponse = (HttpWebResponse)webExc.Response;
        //            }
        //        }, request);

        //        //Debug.WriteLine(response.ContentType);
        //        //// Read the response into a Stream object.
        //        //System.IO.Stream responseStream = response.GetResponseStream();
        //        //string data;
        //        //using (var reader = new System.IO.StreamReader(responseStream))
        //        //{
        //        //    data = reader.ReadToEnd();
        //        //}
        //        //responseStream.Close();

        //        //  return null;

        //        //var feed = Newtonsoft.Json.JsonConvert.DeserializeObject<SupplierODataFeed>(data);
        //        //SuppliersList.ItemsSource = feed.d.results;
        //    }
        //    catch (Exception ex)
        //    {
        //        var we = ex.InnerException as WebException;
        //        if (we != null)
        //        {
        //            var resp = we.Response as HttpWebResponse;
        //            var code = resp.StatusCode;
        //            MessageBox.Show("RespCallback Exception raised! Message:{0}" + we.Message);
        //            Debug.WriteLine("Status:{0}", we.Status);
        //        }
        //        else
        //            throw;
        //    }
        //}

    }
}
