﻿using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace Pollen
{
    public partial class SplashScreen : UserControl
    {
        private readonly Popup _popup;

        public SplashScreen()
        {
            InitializeComponent();
            progressBar1.IsIndeterminate = true;
        }

        public SplashScreen(Popup popup)
        {
            InitializeComponent();
            progressBar1.IsIndeterminate = true;
            _popup = popup;
        }
    }
}
